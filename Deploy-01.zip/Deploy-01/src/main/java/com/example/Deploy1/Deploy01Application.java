package com.example.Deploy1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Deploy01Application {

	public static void main(String[] args) {
		SpringApplication.run(Deploy01Application.class, args);
	}

}
